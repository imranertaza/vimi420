<script type="text/javascript">
    getDocAndNoteIndexPage();
    setTimeout(() => {
        initializeDocumentAndNoteDataTable();
    }, 200);
</script>
